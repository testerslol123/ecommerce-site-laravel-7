<div class="top_bar">
    <div class="container">
        <div class="row">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="tb_left pull-left">
                        <p>Welcome to our online store !</p>
                    </div>
                    <div class="tb_center pull-left">
                        <ul>
                            <li><i class="fa fa-phone"></i> Hotline: <a href="#">(+62) 899-9900-502</a></li>
                            <li><i class="fa fa-envelope-o"></i> <a href="#">admin@momiku.com</a></li>
                        </ul>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Laravel_Project\ecommerce-momiku\resources\views/layouts/topbar.blade.php ENDPATH**/ ?>