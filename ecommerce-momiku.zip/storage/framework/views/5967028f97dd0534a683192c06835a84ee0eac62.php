
            <!-- CLIENTS -->
            <div class="clients">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="clients-carousel">
                                <div><a href="#"><img src="images/clients/1.png" class="img-responsive" alt=""/></a></div>
                                <div><a href="#"><img src="images/clients/2.png" class="img-responsive" alt=""/></a></div>
                                <div><a href="#"><img src="images/clients/3.png" class="img-responsive" alt=""/></a></div>
                                <div><a href="#"><img src="images/clients/4.png" class="img-responsive" alt=""/></a></div>
                                <div><a href="#"><img src="images/clients/5.png" class="img-responsive" alt=""/></a></div>
                                <div><a href="#"><img src="images/clients/6.png" class="img-responsive" alt=""/></a></div>
                                <div><a href="#"><img src="images/clients/1.png" class="img-responsive" alt=""/></a></div>
                                <div><a href="#"><img src="images/clients/2.png" class="img-responsive" alt=""/></a></div>
                                <div><a href="#"><img src="images/clients/3.png" class="img-responsive" alt=""/></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php /**PATH C:\Laravel_Project\ecommerce-momiku\resources\views/homepage/client.blade.php ENDPATH**/ ?>