            <!-- POLICY -->
            <div class="policy-item parallax-bg1">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-3">
                            <div class="pi-wrap text-center">
                                <i class="fa fa-plane"></i>
                                <h4>Free shipping<span>Free shipping on all UK order</span></h4>
                                <p>Nulla ac nisi egestas metus aliquet euismod. Sed pulvinar lorem at pretium.</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="pi-wrap text-center">
                                <i class="fa fa-money"></i>
                                <h4>Money Guarantee<span>30 days money back guarantee !</span></h4>
                                <p>Curabitur ornare urna enim, et lacinia purus tristique eulla eget feugiat diam.</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="pi-wrap text-center">
                                <i class="fa fa-clock-o"></i>
                                <h4>Store Hours<span>Open: 9:00AM - Close: 21:00PM</span></h4>
                                <p>Etiam egestas purus eget sagittis lacinia. Morbi vel elit nec eros iaculis.</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3">
                            <div class="pi-wrap text-center">
                                <i class="fa fa-life-ring"></i>
                                <h4>Support 24/7<span>We support online 24 hours a day</span></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit integer congue.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php /**PATH C:\Laravel_Project\ecommerce-momiku\resources\views/homepage/policy.blade.php ENDPATH**/ ?>