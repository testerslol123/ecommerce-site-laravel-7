

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- SLIDER -->
	<?php echo $__env->make('homepage.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- BLOCKS WRAP -->
    

    <div class="clearfix"></div>

    <?php echo $__env->make('homepage.featured-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('homepage.policy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    



<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
	<?php echo $__env->make('homepage.shop-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-widget'); ?>
	<?php echo $__env->make('homepage.footer-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('newsletter'); ?>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel_Project\ecommerce-momiku\resources\views/homepage/index.blade.php ENDPATH**/ ?>