            <!-- BLOG -->
            <div class="home-blog">
                <div class="container">
                    <h5 class="heading space40"><span>Latest from our blog</span></h5>
                    <div class="row">
                        <div class="col-md-4 col-sm-4">
                            <article class="home-post text-center">
                                <div class="post-thumb">
                                    <a href="./blog-single.html">
                                        <img src="images/blog/1/1.jpg" class="img-responsive" alt=""/>
                                        <div class="overlay-rmore fa fa-link"></div>
                                    </a>
                                </div>
                                <div class="post-excerpt">
                                    <h4><a href="./blog-single.html">A Beautiful & Creative design</a></h4>
                                    <div class="hp-meta">
                                        <span><i class="fa fa-edit"></i> September 25, 1989</span>
                                        <span><i class="fa fa-comment-o"></i> <a href="#">2037 Comments</a></span>
                                    </div>
                                    <p>Fusce id viverra leo, quis sollicitudin risus. Sed maximus dictum semper. Sed laoreet euismod dui [..]</p>
                                </div>
                            </article>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <article class="home-post text-center">
                                <div class="post-thumb">
                                    <a href="./blog-single.html">
                                        <img src="images/blog/1/2.jpg" class="img-responsive" alt=""/>
                                        <div class="overlay-rmore fa fa-link"></div>
                                    </a>
                                </div>
                                <div class="post-excerpt">
                                    <h4><a href="./blog-single.html">A Beautiful & Creative design</a></h4>
                                    <div class="hp-meta">
                                        <span><i class="fa fa-edit"></i> September 25, 1989</span>
                                        <span><i class="fa fa-comment-o"></i> <a href="#">2037 Comments</a></span>
                                    </div>
                                    <p>Fusce id viverra leo, quis sollicitudin risus. Sed maximus dictum semper. Sed laoreet euismod dui [..]</p>
                                </div>
                            </article>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <article class="home-post text-center">
                                <div class="post-thumb">
                                    <a href="./blog-single.html">
                                        <img src="images/blog/1/3.jpg" class="img-responsive" alt=""/>
                                        <div class="overlay-rmore fa fa-link"></div>
                                    </a>
                                </div>
                                <div class="post-excerpt">
                                    <h4><a href="./blog-single.html">A Beautiful & Creative design</a></h4>
                                    <div class="hp-meta">
                                        <span><i class="fa fa-edit"></i> September 25, 1989</span>
                                        <span><i class="fa fa-comment-o"></i> <a href="#">2037 Comments</a></span>
                                    </div>
                                    <p>Fusce id viverra leo, quis sollicitudin risus. Sed maximus dictum semper. Sed laoreet euismod dui [..]</p>
                                </div>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
<?php /**PATH C:\Laravel_Project\ecommerce-momiku\resources\views/homepage/blog.blade.php ENDPATH**/ ?>