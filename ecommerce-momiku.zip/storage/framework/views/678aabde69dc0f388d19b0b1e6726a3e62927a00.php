            <!-- TESTIMONIAL -->
            <div class="testimonial parallax-bg2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="quote-carousel">
                                <div>
                                    <img src="images/quote/1.png" class="img-responsive" alt=""/>
                                    <div class="quote-info">
                                        <h4>Smile Nguyen</h4>
                                        <cite>Themeforest</cite>	
                                        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris convallis odio in faucibus posuere. In eu scelerisque lorem. Mauris lusto in lacus accumsan interdum.Nam mattis sollicitudin vestibulum"</p>
                                    </div>
                                </div>
                                <div>
                                    <img src="images/quote/2.png" class="img-responsive" alt=""/>
                                    <div class="quote-info">
                                        <h4>Smile Nguyen</h4>
                                        <cite>Themeforest</cite>	
                                        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris convallis odio in faucibus posuere. In eu scelerisque lorem. Mauris lusto in lacus accumsan interdum.Nam mattis sollicitudin vestibulum"</p>
                                    </div>
                                </div>
                                <div>
                                    <img src="images/quote/3.png" class="img-responsive" alt=""/>
                                    <div class="quote-info">
                                        <h4>Smile Nguyen</h4>
                                        <cite>Themeforest</cite>	
                                        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris convallis odio in faucibus posuere. In eu scelerisque lorem. Mauris lusto in lacus accumsan interdum.Nam mattis sollicitudin vestibulum"</p>
                                    </div>
                                </div>
                                <div>
                                    <img src="images/quote/3.png" class="img-responsive" alt=""/>
                                    <div class="quote-info">
                                        <h4>Smile Nguyen</h4>
                                        <cite>Themeforest</cite>	
                                        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris convallis odio in faucibus posuere. In eu scelerisque lorem. Mauris lusto in lacus accumsan interdum.Nam mattis sollicitudin vestibulum"</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php /**PATH C:\Laravel_Project\ecommerce-momiku\resources\views/homepage/testimonial.blade.php ENDPATH**/ ?>