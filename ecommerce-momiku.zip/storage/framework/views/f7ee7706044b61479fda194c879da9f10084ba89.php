<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
    <head>
        <?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('css'); ?>
    </head>
    <body>

        <!-- PRELOADER -->
        <div id="loader"></div>

        <div class="body">
            <!-- TOPBAR -->
            <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- HEADER -->
            


            <?php echo $__env->yieldContent('content'); ?>









            <!-- FOOTER WIDGETS -->
            <?php echo $__env->yieldContent('footer-widget'); ?>
            <!-- FOOTER -->
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

        <?php echo $__env->yieldContent('newsletter'); ?>


        <?php echo $__env->yieldContent('modal'); ?>
        <div id="backtotop"><i class="fa fa-chevron-up"></i></div>



        <?php echo $__env->make('layouts.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('javascript'); ?>
    </body>
</html><?php /**PATH C:\Laravel_Project\ecommerce-momiku\resources\views/layouts/layouts.blade.php ENDPATH**/ ?>