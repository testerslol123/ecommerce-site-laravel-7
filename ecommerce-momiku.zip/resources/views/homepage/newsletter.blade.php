        <!-- Newsletter -->
        <div class="subscribe-me">
            <a href="#close" class="sb-close-btn">x</a>
            <div id="popup-newsletter">
                <div class="block-content">
                    <div class="form-subscribe-header">
                        <label>Join Our Email Letter</label>
                    </div>
                    <div class="clearfix space30"></div>
                    <span class="promo-panel-sale">TAKE 25% OFF YOUR NEXT PURCHASE !</span>
                    <div class="clearfix space30"></div>
                    <span class="promo-panel-text"></span>
                    <div class="clearfix space30"></div>
                    <div class="input-box">
                        <input name="email" id="pnewsletter" title="Sign up for our newsletter" class="input-text required-entry validate-email" type="text">
                    </div>
                    <div class="actions">
                        <button type="submit" title="JOIN NOW !" class="button"><span><span>JOIN NOW !</span></span></button>
                    </div>
                    <span class="promo-panel-text1">No Thank ! I'm not interested in this promotion </span><br>
                    <span class="promo-panel-text2">Entering your email also subscribe you to the latest Sunshine furniture news and offers *</span>
                    <label class="subscribe-bottom"><input type="checkbox"><span>Don't show this popup again</span></label>
                </div>
            </div>
        </div>
