<div class="top_bar">
    <div class="container">
        <div class="row">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="tb_left pull-left">
                        <p>Welcome to our online store !</p>
                    </div>
                    <div class="tb_center pull-left">
                        <ul>
                            <li><i class="fa fa-phone"></i> Hotline: <a href="#">(+62) 899-9900-502</a></li>
                            <li><i class="fa fa-envelope-o"></i> <a href="#">admin@momiku.com</a></li>
                        </ul>
                    </div>
                    {{-- 
                    <div class="tb_right pull-right">
                        <ul>
                            <li>
                                <div class="tbr-info">
                                    <span>Account <i class="fa fa-caret-down"></i></span>
                                    <div class="tbr-inner">
                                        <a href="my-account.html">My Account</a>
                                        <a href="#">My Wishlist</a>
                                        <a href="#">Checkout</a>
                                        <a href="login-page.html">Login</a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="tbr-info">
                                    <span><img src="images/basic/flag1.png" alt=""/>&nbsp;English <i class="fa fa-caret-down"></i></span>
                                    <div class="tbr-inner">
                                        <a href="#"><img src="images/basic/flag1.png" alt=""/>English</a>
                                        <a href="#"><img src="images/basic/flag2.png" alt=""/>French</a>
                                        <a href="#"><img src="images/basic/flag3.png" alt=""/>German</a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="tbr-info">
                                    <span>US Dollar <i class="fa fa-caret-down"></i></span>
                                    <div class="tbr-inner">
                                        <a href="#">&euro; Euro</a>
                                        <a href="#">&pound; Pound</a>
                                        <a href="#">&yen; Yen</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                     --}}
                </div>
            </div>
        </div>
    </div>
</div>
